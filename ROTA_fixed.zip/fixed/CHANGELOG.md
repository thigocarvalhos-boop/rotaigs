# ROTA — Registro de Correções Estruturais
## Auditoria Técnica Completa — Abril 2026

---

## ÍNDICE DE FALHAS IDENTIFICADAS E CORRIGIDAS

| ID   | Severidade | Arquivo(s) Afetado(s) | Impacto em Produção |
|------|------------|----------------------|---------------------|
| F1   | ALTA       | schema.prisma        | Campos do projeto nunca persistidos no banco |
| F2   | MÉDIA      | schema.prisma        | ptScore decimais truncados silenciosamente |
| F3   | ALTA       | schema.prisma + alertService.ts + App.tsx | Todos os dias de alerta exibiam 0 |
| F4   | ALTA       | schema.prisma        | Documentos institucionais não podiam ser criados |
| F5   | BAIXA      | schema.prisma        | Inconsistência de design (sem impacto de runtime) |
| F6   | CRÍTICA    | server.ts            | POST /api/projects falhava com qualquer campo extra |
| F7   | ALTA       | server.ts            | PATCH /api/projects/:id/status inexistente |
| F8   | ALTA       | server.ts            | PATCH e DELETE de projetos inexistentes |
| F9   | BAIXA      | server.ts            | PORT hardcoded, ignorava variável de ambiente |
| F11  | CRÍTICA    | App.tsx              | Datas exibidas com formato corrompido |
| F12  | CRÍTICA    | App.tsx              | Validade de documentos corrompida no render |
| F13  | CRÍTICA    | App.tsx              | project.responsavel exibia "[object Object]" |
| F14  | ALTA       | App.tsx              | Título dos alertas sempre em branco |
| F15  | ALTA       | App.tsx              | Countdown de alertas sempre exibia 0 dias |
| F16  | CRÍTICA    | vite.config.ts       | GEMINI_API_KEY exposta no bundle do cliente |
| F17  | ALTA       | types.ts             | Project.responsavel tipado incorretamente |

---

## DESCRIÇÃO DETALHADA POR CORREÇÃO

---

### F1 — Campos do Projeto Ausentes no Schema Prisma
**Arquivo:** `prisma/schema.prisma`
**Causa-raiz:** O modelo `Project` no schema Prisma não incluía campos que existiam
na interface TypeScript (`src/types.ts`) e nos dados mock (`src/mockData.ts`):
`observacao`, `ano`, `categoriaEdital`, `programaInterno`, `vigenciaInicio`,
`vigenciaFim`, `progressoFisico`, `progressoFinanceiro`, `scoreCompliance`,
`scoreRiscoGlosa`, `ptCriterios`, `historico`, `changeLog`.

**Impacto:** Ao criar ou buscar projetos via API, esses campos eram silenciosamente
descartados. Nenhum dado histórico, score de compliance, ou ptCriterios era persistido.
O sistema aparentava funcionar mas não salvava dados estruturais críticos.

**Correção:** Adicionados todos os campos faltantes ao modelo `Project`.
Os campos `ptCriterios`, `historico` e `changeLog` foram tipados como `Json?`
— uma tabela separada para cada um seria overkill dado que não há necessidade
de queries por critério individual. Os demais são tipos primitivos opcionais.

---

### F2 — ptScore Declarado como Int, Silenciosamente Trunca Decimais
**Arquivo:** `prisma/schema.prisma`
**Causa-raiz:** O campo `ptScore` estava declarado como `Int` no schema Prisma,
mas os dados reais (mockData e o modelo de domínio) usam valores decimais
como `8.1`, `7.2`, `9.5`. O Prisma converte Float → Int silenciosamente,
sem erro.

**Impacto:** `ptScore: 8.1` era salvo como `8`, `ptScore: 7.2` como `7`.
A precisão analítica do PTI era perdida em todas as gravações. O dashboard
exibia scores incorretos para todos os projetos.

**Correção:** `ptScore Int` → `ptScore Float @default(0)`.

---

### F3 — Alert.prazo Ausente: Todos os Alertas Exibiam 0 Dias
**Arquivos:** `prisma/schema.prisma`, `src/services/alertService.ts`, `src/App.tsx`
**Causa-raiz:** O modelo `Alert` no Prisma não tinha campo `prazo`. O `alertService.create()`
não aceitava nem gravava prazo. No frontend, o mapeamento de alertas tentava usar `a.prazo`:

```ts
dias: a.prazo
  ? Math.ceil((new Date(a.prazo).getTime() - Date.now()) / 86400000)
  : Math.ceil((new Date(a.createdAt).getTime() - Date.now()) / 86400000)
```

Como `a.prazo` era sempre `undefined` (campo inexistente no DB), o código caía
no fallback `createdAt`. Como alertas são criados no passado, `createdAt < Date.now()`,
resultando em valor negativo → `Math.max(0, negative)` = **0 para todos os alertas**.

**Impacto:** O módulo de alertas era funcionalmente inútil para gestão de prazos.
Todos os contadores mostravam "0 dias". A diretoria não tinha como priorizar urgências.

**Correção em 3 camadas:**
1. `schema.prisma`: Adicionado `prazo DateTime?` ao modelo `Alert`
2. `alertService.ts`: Interface `create()` agora aceita `prazo?: Date` e o persiste.
   `checkDocumentExpirations()` agora passa `doc.validade` como `prazo` do alerta.
3. `App.tsx`: Mapeamento corrigido para usar `a.prazo` do banco; `titulo: a.titulo`
   adicionado (ver F14).

---

### F4 — Document.projectId Não-Nulo Impedia Documentos Institucionais
**Arquivo:** `prisma/schema.prisma`
**Causa-raiz:** O campo `projectId String` no modelo `Document` era obrigatório
(não-nulo). Documentos institucionais (Estatuto Social, CNPJ, certidões) existem
independentemente de qualquer projeto específico.

**Impacto:** Era impossível criar documentos sem vinculá-los a um projeto, mesmo
que `POST /api/documents` aceitasse `projectId` opcional no body. O Prisma lançaria
um erro de constraint ao tentar `projectId: null`.

**Correção:** `projectId String` → `projectId String?` com relação opcional
`project Project? @relation(...)`. Adicionado `onDelete: SetNull` para que
documentos não sejam deletados em cascata quando o projeto é removido.

---

### F5 — vincMetaId e vincEtapaId em Expense sem @relation Formal
**Arquivo:** `prisma/schema.prisma`
**Causa-raiz:** `Expense.vincMetaId` e `Expense.vincEtapaId` eram campos `String`
sem nenhuma diretiva `@relation`, sem back-relations em `Meta` e `Etapa`.

**Impacto:** O Prisma não valida a integridade referencial desses campos. Um expense
poderia referenciar uma Meta ou Etapa inexistente sem erro. Também impede queries
relacionais eficientes (ex: `include: { vincMeta: true }`).

**Correção:** Adicionadas relações explícitas `vincMeta Meta @relation(...)` e
`vincEtapa Etapa @relation(...)` com back-relations correspondentes em ambos os modelos.

---

### F6 — POST /api/projects Espalhava req.body Diretamente no Prisma
**Arquivo:** `server.ts`
**Causa-raiz:**
```ts
const project = await prisma.project.create({
  data: {
    ...data,  // data = req.body inteiro
    responsavelId: req.user.id,
    status: "Triagem",
    prazo: new Date(data.prazo)
  }
})
```
O Prisma lança `PrismaClientValidationError` para qualquer campo desconhecido
passado no `data`. Qualquer cliente que enviasse campos extras (ou campos que o
Prisma não reconhece, como arrays de `docs`, `metas`, `etapas`) causaria crash 500.
Além disso, um cliente malicioso poderia injetar `id`, `createdAt`, ou sobrescrever
`responsavelId` antes do spread.

**Impacto:** O endpoint de criação de projetos estava quebrado para qualquer payload
que incluísse campos além dos básicos. Todas as criações do frontend (que inclui
`ptCriterios`, `historico`, `docs` como arrays) resultariam em erro 400/500.

**Correção:** Implementada função `sanitizeProjectData()` com allowlist explícita de
campos aceitos. Apenas campos conhecidos passam para o Prisma. `responsavelId` é
sempre sobrescrito pelo `req.user.id` do token JWT, nunca do body.

---

### F7 — PATCH /api/projects/:id/status Inexistente
**Arquivo:** `server.ts`
**Causa-raiz:** O botão "Atualizar Status" na tela de detalhes do projeto chamaria
`ProjectsAPI.updateStatus(id, status)` → `POST /api/projects/:id/status`, mas este
endpoint nunca foi implementado no `server.ts`.

**Impacto:** A funcionalidade de mudança de status (ação mais frequente no sistema)
resultaria em 404. O ciclo de vida dos projetos era não-funcional via UI.

**Correção:** Endpoint `PATCH /api/projects/:id/status` implementado com:
- Validação de status contra a lista de valores permitidos
- Atualização atômica do campo `status`
- Append automático de entrada no `changeLog` (Json) com autor, data, e justificativa
- Log de auditoria via `auditService`

---

### F8 — PATCH e DELETE de Projetos Inexistentes
**Arquivo:** `server.ts`
**Causa-raiz:** Não existia nenhum endpoint para atualizar campos de um projeto
(`PATCH /api/projects/:id`) nem para deletá-lo (`DELETE /api/projects/:id`).

**Impacto:** Impossível editar qualquer dado de projeto após a criação. Impossível
remover projetos indevidos. O sistema era somente leitura após o seed inicial.

**Correção:** Implementados ambos os endpoints com sanitização de campos (mesma
allowlist de F6), verificação de existência, log de auditoria, e validação de
permissões via `can("projects:update")` e `can("projects:delete")`.

---

### F9 — PORT Hardcoded como 3000
**Arquivo:** `server.ts`
**Causa-raiz:** `const PORT = 3000;` ignora `process.env.PORT`.

**Impacto:** Em ambientes de produção onde a porta é definida via variável de
ambiente (Heroku, Railway, Render, etc.), o servidor sempre tentaria bindar na porta
3000, falhando ou conflitando com outro processo.

**Correção:** `const PORT = parseInt(process.env.PORT || "3000", 10);`

---

### F11 — Datas Exibidas com Formato Corrompido
**Arquivo:** `src/App.tsx`
**Causa-raiz:** O código usava `.split("-").reverse().join("/")` assumindo que as
datas teriam o formato `"YYYY-MM-DD"`. Mas o Prisma retorna datas como ISO 8601:
`"2026-04-15T00:00:00.000Z"`.

Resultado: `"2026-04-15T00:00:00.000Z".split("-")` →
`["2026", "04", "15T00:00:00.000Z"]`.reverse().join("/")` →
`"15T00:00:00.000Z/04/2026"`.

**Impacto:** Todas as datas de prazo de projetos, alertas e editais exibiam
strings corrompidas. O sistema era ilegível para qualquer dado vindo do banco.

**Correção:** Função helper `formatDate(value: string | null | undefined): string`
adicionada. Usa `new Date(value).toLocaleDateString("pt-BR")`, que aceita qualquer
formato de data válido. Substituída em todas as ocorrências do padrão anterior.

---

### F12 — Validade de Documentos Corrompida no Render
**Arquivo:** `src/App.tsx`
**Causa-raiz:** Mesma raiz que F11 — `doc.validade.split("-").reverse().join("/")`
aplicado a ISO datetime string do banco.

**Correção:** Substituído por `formatDate(doc.validade)`.

---

### F13 / F17 — project.responsavel Exibia "[object Object]"
**Arquivos:** `src/App.tsx`, `src/types.ts`
**Causa-raiz:** O backend retorna `responsavel` como um objeto User completo
(via `include: { responsavel: true }` no Prisma). O tipo TypeScript declarava
`responsavel: string`, e a UI renderizava `project.responsavel` diretamente como JSX.
Quando `responsavel` é um objeto `{ id, name, email, role }`, React converte para
`"[object Object]"`.

**Impacto:** O nome do responsável nunca era exibido. Em todos os cards de projeto
e na página de detalhes, o campo "Responsável" mostrava "[object Object]".

**Correção:**
- `types.ts`: `responsavel: string | UserRef` onde `UserRef = { id, name, email, role }`
- `App.tsx`: Helper `getResponsavelName(responsavel: string | UserRef): string`
  — retorna `responsavel.name` se for objeto, ou o valor direto se for string
  (compatível com mockData que usa strings).

---

### F14 — Título dos Alertas Sempre em Branco
**Arquivo:** `src/App.tsx`
**Causa-raiz:** O mapeamento de alertas da API para o tipo `AlertType` não incluía
o campo `titulo`:
```ts
const mappedAlerts: AlertType[] = aData.map((a: any) => ({
  id: a.id,
  nivel: a.nivel,
  tipo: a.tipo,
  // titulo estava ausente aqui
  mensagem: a.mensagem
}))
```
Na `AlertasView`, o header do card exibia `{a.titulo}` — que era `undefined`.

**Impacto:** Todos os títulos de alerta estavam em branco. O componente `AlertasView`
mostrava apenas linhas vazias como heading de cada alerta.

**Correção:** Adicionado `titulo: a.titulo` ao mapeamento. Fallback adicionado
na renderização: `{a.titulo || a.tipo}`.

---

### F15 — Countdown de Alertas Sempre Exibia 0 Dias
**Arquivo:** `src/App.tsx`
**Causa-raiz:** Ver F3. O campo `Alert.prazo` não existia no banco, então `a.prazo`
era sempre `undefined` no mapeamento, fazendo o código cair no fallback `createdAt`.
Como alertas existem no passado, o cálculo resultava em número negativo →
`Math.max(0, negativo)` = 0.

**Impacto:** O countdown de todos os alertas mostrava "0 dias", tornando impossível
priorizar por urgência na interface.

**Correção:** Após a adição de `Alert.prazo` no schema (F3) e sua propagação pelo
alertService, o mapeamento agora usa `a.prazo` corretamente para o cálculo de `dias`.

---

### F16 — GEMINI_API_KEY Exposta no Bundle do Cliente
**Arquivo:** `vite.config.ts`
**Causa-raiz:**
```ts
define: {
  'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
}
```
O bloco `define` do Vite substitui literalmente `process.env.GEMINI_API_KEY` por
o valor da variável em tempo de build, embutindo a chave como string literal no
bundle JavaScript servido ao browser. Qualquer pessoa pode inspecionar o bundle
e extrair a chave.

**Impacto:** Exposição de credencial de API em produção. A chave pode ser usada
por terceiros para consumir a quota da API Gemini. Vulnerabilidade de segurança
crítica se a chave estiver configurada.

**Correção:** O bloco `define` foi removido completamente do `vite.config.ts`.
O `gemini.ts` é uma lib server-side que lê `process.env.GEMINI_API_KEY` em
runtime do Node — não precisa de substituição em build-time.

---

## SUMÁRIO DE ARQUIVOS MODIFICADOS

| Arquivo | Tipo de Mudança | Fixes |
|---------|----------------|-------|
| `prisma/schema.prisma` | Reescrita completa | F1, F2, F3, F4, F5 |
| `server.ts` | Reescrita completa | F6, F7, F8, F9 |
| `src/services/alertService.ts` | Atualização | F3 |
| `src/types.ts` | Atualização | F17 |
| `src/App.tsx` | Reescrita completa | F11, F12, F13, F14, F15 |
| `vite.config.ts` | Atualização | F16 |

---

## PROCEDIMENTO DE MIGRAÇÃO

```bash
# 1. Substituir os arquivos corrigidos
cp -r fixed/* .

# 2. Regerar o cliente Prisma após mudanças no schema
npx prisma generate

# 3. Criar e aplicar migration para as novas colunas
npx prisma migrate dev --name "add_missing_project_fields_and_alert_prazo"

# 4. Verificar que a migration foi aplicada
npx prisma migrate status

# 5. Rebuild do frontend
npm run build

# 6. Reiniciar o servidor
npm run dev
```

### Impacto da Migration nos Dados Existentes

Todos os novos campos adicionados ao modelo `Project` são opcionais (`?`) ou têm
`@default(0)` / `@default("")`, garantindo compatibilidade retroativa com registros
existentes. A mudança `ptScore Int → Float` é compatível com dados Int existentes.

O novo campo `Alert.prazo DateTime?` é opcional — alertas existentes terão
`prazo = null`, o que o frontend trata graciosamente (exibindo "0 dias").
Novos alertas criados pelo `alertService` a partir desta versão terão `prazo`
preenchido corretamente.

---

*Auditoria concluída em Abril de 2026.*
