// vite.config.ts
// FIX LOG:
// [F16] Removed `define: { 'process.env.GEMINI_API_KEY': ... }`.
//       This was embedding the API key as a plain string literal in the client-side
//       JavaScript bundle, exposing it to anyone who downloads the page assets.
//       The gemini.ts lib is server-only — it reads process.env.GEMINI_API_KEY
//       at Node runtime. Exposing it via Vite define serves no purpose and is a
//       security vulnerability.

import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig } from 'vite';

export default defineConfig({
  plugins: [react(), tailwindcss()],
  // [F16] No `define` block — GEMINI_API_KEY must never reach the client bundle.
  //       Server code reads it directly from process.env at Node runtime.
  resolve: {
    alias: {
      '@': path.resolve(__dirname, '.'),
    },
  },
  server: {
    hmr: process.env.DISABLE_HMR !== 'true',
  },
});
