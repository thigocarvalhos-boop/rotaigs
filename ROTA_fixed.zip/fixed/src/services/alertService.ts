// src/services/alertService.ts
// FIX LOG:
// [F3] alertService.create now accepts optional `prazo: Date` parameter and persists
//      it to the Alert record. Without this, Alert.prazo was always null in the DB,
//      causing the frontend countdown (dias) to always compute as 0.
// [F3] checkDocumentExpirations now passes doc.validade as the alert prazo,
//      so the countdown correctly reflects the document's expiration date.

import { prisma } from "../lib/prisma";

interface CreateAlertParams {
  projectId?: string;
  titulo: string;
  mensagem: string;
  nivel: string;
  tipo: string;
  // [F3] New field: the actual deadline this alert refers to
  prazo?: Date;
}

export const alertService = {
  async create({ projectId, titulo, mensagem, nivel, tipo, prazo }: CreateAlertParams) {
    return prisma.alert.create({
      data: {
        projectId: projectId ?? null,
        titulo,
        mensagem,
        nivel,
        tipo,
        status: "PENDENTE",
        // [F3] Persist the deadline. Previously this field did not exist and was
        //      never passed, so countdown calculations in the frontend fell back
        //      to createdAt, always yielding 0.
        prazo: prazo ?? null,
      },
    });
  },

  async checkDocumentExpirations() {
    const now = new Date();
    const horizon = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000); // +30 days

    const docs = await prisma.document.findMany({
      where: {
        validade: { not: null, lte: horizon },
        status: { not: "VENCIDO" },
      },
    });

    for (const doc of docs) {
      if (!doc.validade) continue;

      const isExpired = doc.validade < now;

      // [F3] Pass doc.validade as the alert's prazo so the frontend can compute
      //      an accurate countdown. Previously prazo was never set.
      await alertService.create({
        projectId: doc.projectId ?? undefined,
        titulo: isExpired ? "Documento Vencido" : "Documento a Vencer",
        mensagem: `O documento "${doc.nome}" ${
          isExpired ? "venceu" : "vencerá"
        } em ${doc.validade.toLocaleDateString("pt-BR")}.`,
        nivel: isExpired ? "N4" : "N2",
        tipo: "DOCUMENTO",
        prazo: doc.validade, // [F3] Was missing — now the countdown is correct
      });

      if (isExpired) {
        await prisma.document.update({
          where: { id: doc.id },
          data: { status: "VENCIDO" },
        });
      }
    }
  },

  async checkBudgetOverrun(projectId: string) {
    const metas = await prisma.meta.findMany({
      where: { projectId },
      include: {
        expenses: { where: { status: "VALIDADO" } },
      },
    });

    for (const meta of metas) {
      const totalSpent = meta.expenses.reduce((sum, e) => sum + e.valor, 0);

      if (totalSpent > meta.budget) {
        await alertService.create({
          projectId,
          titulo: "Orçamento Estourado",
          mensagem: `Meta "${meta.descricao}" ultrapassou o orçamento. Gasto: R$\u00a0${totalSpent.toLocaleString(
            "pt-BR"
          )}, Limite: R$\u00a0${meta.budget.toLocaleString("pt-BR")}`,
          nivel: "N4",
          tipo: "ORCAMENTO",
          // No prazo for budget alerts — the event already happened
        });
      }
    }
  },
};
