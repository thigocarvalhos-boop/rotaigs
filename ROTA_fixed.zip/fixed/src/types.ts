// src/types.ts
// FIX LOG:
// [F17] Project.responsavel changed from `string` to `string | UserRef` because
//       the backend returns the full User object via Prisma include.
//       Previously `project.responsavel` rendered as "[object Object]" in the UI.
// [F1]  Added all fields that exist in mockData/Prisma schema but were absent from
//       the TypeScript interface (observacao, ano, categoriaEdital, etc.).
// [F2]  ptScore confirmed as `number` (was typed as number already, but Prisma
//       schema had it as Int — schema now fixed to Float).

export type ProjectStatus =
  | "Oportunidade"
  | "Triagem"
  | "Elaboração"
  | "Revisão"
  | "Pronto"
  | "Inscrito"
  | "Diligência"
  | "Aprovado"
  | "Não Aprovado"
  | "Captado"
  | "Formalização"
  | "Execução"
  | "Concluído"
  | "Arquivado";

// [F17] Represents the User object returned by Prisma includes
export interface UserRef {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface PTICriterion {
  critério: string;
  score: number;
}

export interface ProjectHistory {
  data: string;
  acao: string;
  autor: string;
  detalhes?: string;
}

export interface ChangeLog {
  id: string;
  data: string;
  autor: string;
  campo: "valor" | "status" | "probabilidade";
  valorAnterior: string | number;
  valorNovo: string | number;
  justificativa?: string;
}

export interface Document {
  id: string;
  nome: string;
  status: "Aprovado" | "Pendente" | "Em Revisão" | "A Vencer" | "Vencido" | "Em Análise";
  // [F11][F12] validade is an ISO datetime string from the DB, not a YYYY-MM-DD string.
  // Use formatDate() helper in components — never call .split('-').reverse() directly.
  validade: string | null;
  url?: string;
  project?: { id: string; nome: string };
  obrigatorio?: boolean;
  versao?: number;
}

export interface Meta {
  id: string;
  descricao: string;
  indicador: string;
  meta: number;
  alcancado: number;
  unidade: string;
  budget: number;
}

export interface Etapa {
  id: string;
  nome: string;
  // ISO datetime strings from the DB
  inicio: string;
  fim: string;
  status: "Planejado" | "Em curso" | "Concluído" | "Atrasado";
  peso: number;
}

export interface Cotacao {
  id: string;
  fornecedor: string;
  valor: number;
  data: string;
  vencedora: boolean;
  docUrl?: string;
}

export interface Expense {
  id: string;
  descricao: string;
  valor: number;
  data: string;
  categoria: string;
  status: "Pendente" | "Validado" | "Glosa" | "Em Análise";
  justificativa?: string;
  vincMetaId: string;
  vincEtapaId: string;
  cotacoes: Cotacao[];
}

export interface Edital {
  id: string;
  nome: string;
  financiador: string;
  valorMax: number;
  prazo: string;
  status: "Aberto" | "Encerrado" | "Em análise";
  aderencia: number;
  categoria: string;
  linha: string;
  porte: "Micro" | "Pequeno" | "Médio" | "Grande";
  link?: string;
  observacao?: string;
}

export interface ComplianceCheck {
  id: string;
  item: string;
  status: "Conforme" | "Não Conforme" | "N/A";
  observacao?: string;
  data: string;
}

export interface AuditLog {
  id: string;
  data: string;
  usuario: string;
  acao: string;
  entidade: string;
  entidadeId: string;
  detalhes: string;
}

export interface Project {
  id: string;
  nome: string;
  edital: string;
  financiador: string;
  area: string;
  valor: number;
  status: ProjectStatus;
  // [F11] prazo is an ISO datetime string from the DB ("2026-04-15T00:00:00.000Z").
  // Never call .split('-').reverse().join('/') on this. Use formatDate() instead.
  prazo: string;

  // [F17] responsavel is a UserRef object when coming from the API (Prisma include),
  //       or a plain string when coming from mockData. Use getResponsavelName() helper.
  responsavel: string | UserRef;

  probabilidade: number;
  risco: "Baixo" | "Médio" | "Alto";
  aderencia: number;
  territorio: string;
  publico: string;
  competitividade: string;
  proximoPasso: string;
  ptScore: number;
  ptCriterios: PTICriterion[];
  historico: ProjectHistory[];
  changeLog?: ChangeLog[];
  docs: Document[];
  observacao: string;
  ano: number;
  programaInterno?: string;
  categoriaEdital: string;
  vigenciaInicio?: string;
  vigenciaFim?: string;
  progressoFisico?: number;
  progressoFinanceiro?: number;

  // Compliance & Execution
  metas?: Meta[];
  etapas?: Etapa[];
  expenses?: Expense[];
  complianceChecks?: ComplianceCheck[];
  auditLogs?: AuditLog[];
  scoreCompliance?: number;
  scoreRiscoGlosa?: number;
}

export interface Alert {
  id: string | number;
  nivel: "N1" | "N2" | "N3" | "N4";
  tipo: string;
  projeto: string;
  // [F11] prazo from the DB is an ISO datetime string
  prazo: string;
  dias: number;
  cor: string;
  bgCor: string;
  titulo?: string;
  mensagem?: string;
  doc?: string;
  acaoRecomendada?: string;
}
