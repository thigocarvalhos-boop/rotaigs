// server.ts
// FIX LOG:
// [F5]  PORT now reads process.env.PORT instead of being hardcoded to 3000.
// [F6]  POST /api/projects now uses an explicit allowlist of fields instead of
//       spreading the entire req.body. Prisma throws on unknown fields; spreading
//       raw body caused crashes for any extra client-supplied key.
// [F7]  Added PATCH /api/projects/:id/status endpoint.
// [F8]  Added PATCH /api/projects/:id endpoint (full update).
//       Added DELETE /api/projects/:id endpoint.
// [F3]  alertService.create calls in seed now pass prazo so countdown is valid.
// [F18] AuditLog query uses `select` to avoid ambiguous `data` field conflict
//       with Prisma's reserved internal usage.

import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { body, validationResult } from "express-validator";
import { prisma } from "./src/lib/prisma";
import { auditService } from "./src/services/auditService";
import { alertService } from "./src/services/alertService";

declare global {
  namespace Express {
    interface Request {
      user?: any;
    }
  }
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const JWT_SECRET = process.env.JWT_SECRET;
const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET;

if (!JWT_SECRET || !JWT_REFRESH_SECRET) {
  console.error("FATAL: JWT_SECRET e JWT_REFRESH_SECRET são obrigatórios. Configure o .env.");
  process.exit(1);
}

// [F6] Explicit allowlist for project creation — prevents raw body spread
//      from injecting unknown fields that Prisma rejects at runtime.
const PROJECT_ALLOWED_CREATE_FIELDS = [
  "nome", "edital", "financiador", "area", "valor", "prazo",
  "probabilidade", "risco", "aderencia", "territorio", "publico",
  "competitividade", "proximoPasso", "ptScore", "observacao",
  "ano", "categoriaEdital", "programaInterno",
  "vigenciaInicio", "vigenciaFim",
  "progressoFisico", "progressoFinanceiro",
  "scoreCompliance", "scoreRiscoGlosa",
  "ptCriterios", "historico",
] as const;

const PROJECT_ALLOWED_UPDATE_FIELDS = [
  ...PROJECT_ALLOWED_CREATE_FIELDS,
  "status", "changeLog",
] as const;

function sanitizeProjectData(
  body: Record<string, any>,
  fields: readonly string[]
): Record<string, any> {
  const result: Record<string, any> = {};
  for (const key of fields) {
    if (key in body) {
      result[key] = body[key];
    }
  }
  return result;
}

async function startServer() {
  const app = express();
  // [F5] Read PORT from environment — was hardcoded to 3000
  const PORT = parseInt(process.env.PORT || "3000", 10);

  // ── Seed ──────────────────────────────────────────────────────────────────
  const seedData = async () => {
    if (process.env.NODE_ENV === "production") {
      console.warn("SEED: ignorado em produção. Execute manualmente via npm run seed.");
      return;
    }

    const adminEmail = "admin@guiasocial.org";
    let admin = await prisma.user.findUnique({ where: { email: adminEmail } });

    if (!admin) {
      const hashedPassword = await bcrypt.hash("admin123", 12);
      admin = await prisma.user.create({
        data: {
          email: adminEmail,
          password: hashedPassword,
          name: "Administrador ROTA",
          role: "SUPER_ADMIN",
        },
      });
      console.log("Seed: Admin user created.");
    }

    const projectCount = await prisma.project.count();
    if (projectCount === 0) {
      const cndValidade = new Date("2026-05-20");

      const project = await prisma.project.create({
        data: {
          nome: "Guia Digital Teen 2026",
          edital: "FMCA/COMDICA",
          financiador: "Fundo Municipal da Criança",
          area: "Digital",
          valor: 320000,
          status: "Inscrito",
          prazo: new Date("2026-04-15"),
          responsavelId: admin.id,
          probabilidade: 72,
          risco: "Médio",
          aderencia: 5,
          territorio: "RPA 6 — Pina / Ipsep",
          publico: "Adolescentes 12–18 anos",
          competitividade: "Alta",
          proximoPasso: "Aguardar resultado do edital",
          ptScore: 8.1, // [F2] Float — was Int in original schema, truncated to 8
          observacao: "Alto alinhamento histórico com COMDICA.",
          ano: 2026,
          categoriaEdital: "Fundo Municipal",
          programaInterno: "Inclusão Digital",
          scoreCompliance: 92,
          scoreRiscoGlosa: 8,
          ptCriterios: [
            { critério: "Aderência", score: 9 },
            { critério: "Força Conceitual", score: 8 },
            { critério: "Adequação Financiador", score: 9 },
            { critério: "Cap. Institucional", score: 8 },
            { critério: "Maturidade", score: 7 },
            { critério: "Competitividade", score: 7 },
            { critério: "Plausibilidade Orçam.", score: 8 },
            { critério: "Risco Doc.", score: 9 },
          ],
          historico: [
            { data: "10/02/2026", acao: "Oportunidade identificada", autor: "Janaina Constantino" },
            { data: "14/02/2026", acao: "Triagem aprovada — score 5/5", autor: "Viviane Castro" },
            { data: "12/03/2026", acao: "Submetido", autor: "Viviane Castro" },
          ],
          metas: {
            create: [
              {
                descricao: "Certificar jovens em tecnologia",
                indicador: "Jovens certificados",
                meta: 500,
                alcancado: 380,
                unidade: "Jovens",
                budget: 150000,
              },
            ],
          },
          etapas: {
            create: [
              {
                nome: "Mobilização",
                inicio: new Date("2026-01-01"),
                fim: new Date("2026-02-28"),
                status: "Concluído",
                peso: 20,
              },
              {
                nome: "Execução das Aulas",
                inicio: new Date("2026-03-01"),
                fim: new Date("2026-07-31"),
                status: "Em curso",
                peso: 60,
              },
            ],
          },
          docs: {
            create: [
              { nome: "Estatuto Social", status: "Aprovado", validade: null },
              { nome: "CNPJ", status: "Aprovado", validade: null },
              { nome: "CND Federal", status: "Aprovado", validade: cndValidade },
            ],
          },
        },
      });

      // [F3] Pass prazo so countdown is accurate — was missing in original seed
      await alertService.create({
        projectId: project.id,
        titulo: "Documento Vencendo",
        mensagem: "CND Municipal Recife vence em 15 dias.",
        nivel: "N4",
        status: "PENDENTE",
        tipo: "DOCUMENTO",
        prazo: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
      } as any);

      console.log("Seed: Initial project and alerts created.");
    }
  };

  await seedData();

  await alertService.checkDocumentExpirations();
  setInterval(() => alertService.checkDocumentExpirations(), 60 * 60 * 1000);

  app.use(express.json());

  app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
  });

  // ── Auth Middleware ────────────────────────────────────────────────────────
  const authenticate = (req: any, res: any, next: any) => {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) return res.status(401).json({ error: "Acesso negado" });
    try {
      const decoded = jwt.verify(token, JWT_SECRET!);
      req.user = decoded;
      next();
    } catch {
      res.status(401).json({ error: "Token inválido" });
    }
  };

  // ── RBAC Middleware ────────────────────────────────────────────────────────
  const PERMISSIONS: Record<string, string[]> = {
    "expenses:create":  ["SUPER_ADMIN", "DIRETORIA", "COORDENACAO", "FINANCEIRO"],
    "documents:create": ["SUPER_ADMIN", "DIRETORIA", "COORDENACAO", "DOCUMENTAL"],
    "audit-logs:read":  ["SUPER_ADMIN", "DIRETORIA", "MONITORAMENTO"],
    "alerts:read":      ["SUPER_ADMIN", "DIRETORIA", "COORDENACAO", "MONITORAMENTO", "FINANCEIRO", "ELABORADOR"],
    "projects:create":  ["SUPER_ADMIN", "DIRETORIA", "COORDENACAO"],
    "projects:update":  ["SUPER_ADMIN", "DIRETORIA", "COORDENACAO"],
    "projects:delete":  ["SUPER_ADMIN", "DIRETORIA"],
    "stats:read":       ["SUPER_ADMIN", "DIRETORIA", "COORDENACAO", "MONITORAMENTO"],
  };

  const can = (permission: string) => (req: any, res: any, next: any) => {
    const allowed = PERMISSIONS[permission] || [];
    if (!allowed.includes(req.user?.role)) {
      return res.status(403).json({
        error: "Acesso negado",
        requiredRoles: allowed,
        currentRole: req.user?.role || "desconhecido",
      });
    }
    next();
  };

  // ── Health ─────────────────────────────────────────────────────────────────
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // ── Auth ───────────────────────────────────────────────────────────────────
  app.post(
    "/api/auth/login",
    [body("email").isEmail(), body("password").isLength({ min: 6 })],
    async (req: any, res: any) => {
      const errors = validationResult(req);
      if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

      const { email, password } = req.body;
      try {
        const user = await prisma.user.findUnique({ where: { email } });
        if (!user) return res.status(401).json({ error: "Credenciais inválidas" });

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) return res.status(401).json({ error: "Credenciais inválidas" });

        const accessToken = jwt.sign(
          { id: user.id, email: user.email, role: user.role },
          JWT_SECRET!,
          { expiresIn: "15m" }
        );
        const refreshToken = jwt.sign(
          { id: user.id },
          JWT_REFRESH_SECRET!,
          { expiresIn: "7d" }
        );

        await auditService.log({
          userId: user.id,
          acao: "LOGIN",
          entidade: "User",
          entidadeId: user.id,
        });

        res.json({
          accessToken,
          refreshToken,
          user: { id: user.id, name: user.name, email: user.email, role: user.role },
        });
      } catch {
        res.status(500).json({ error: "Erro interno no servidor" });
      }
    }
  );

  app.post("/api/auth/refresh", async (req: any, res: any) => {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(401).json({ error: "Refresh token ausente" });
    try {
      const decoded = jwt.verify(refreshToken, JWT_REFRESH_SECRET!) as any;
      const user = await prisma.user.findUnique({ where: { id: decoded.id } });
      if (!user) return res.status(401).json({ error: "Usuário não encontrado" });
      const accessToken = jwt.sign(
        { id: user.id, email: user.email, role: user.role },
        JWT_SECRET!,
        { expiresIn: "15m" }
      );
      res.json({ accessToken });
    } catch {
      res.status(401).json({ error: "Refresh token inválido ou expirado" });
    }
  });

  // ── Projects ───────────────────────────────────────────────────────────────
  app.get("/api/projects", authenticate, async (req, res) => {
    try {
      const projects = await prisma.project.findMany({
        include: {
          responsavel: { select: { id: true, name: true, email: true, role: true } },
          alerts: { where: { status: "PENDENTE" } },
          metas: true,
          etapas: true,
          docs: true,
          expenses: { include: { cotacoes: true } },
          compliance: true,
        },
        orderBy: { createdAt: "desc" },
      });
      res.json(projects);
    } catch (error) {
      console.error("[GET /api/projects]", error);
      res.status(500).json({ error: "Erro ao buscar projetos" });
    }
  });

  app.post(
    "/api/projects",
    authenticate,
    can("projects:create"),
    async (req: any, res: any) => {
      try {
        // [F6] Use explicit allowlist — original code spread entire req.body directly,
        //      which caused Prisma runtime errors for unknown fields and allowed
        //      client injection of id, responsavelId, createdAt, etc.
        const allowed = sanitizeProjectData(req.body, PROJECT_ALLOWED_CREATE_FIELDS);

        if (!allowed.nome || !allowed.prazo) {
          return res.status(400).json({ error: "Campos obrigatórios: nome, prazo" });
        }

        const project = await prisma.project.create({
          data: {
            ...allowed,
            responsavelId: req.user.id,
            status: "Triagem",
            prazo: new Date(allowed.prazo),
            vigenciaInicio: allowed.vigenciaInicio ? new Date(allowed.vigenciaInicio) : undefined,
            vigenciaFim: allowed.vigenciaFim ? new Date(allowed.vigenciaFim) : undefined,
          },
          include: {
            responsavel: { select: { id: true, name: true, email: true, role: true } },
          },
        });

        await auditService.log({
          userId: req.user.id,
          projectId: project.id,
          acao: "CREATE",
          entidade: "Project",
          entidadeId: project.id,
          depois: project,
        });

        res.status(201).json(project);
      } catch (error) {
        console.error("[POST /api/projects]", error);
        res.status(400).json({ error: "Erro ao criar projeto" });
      }
    }
  );

  // [F8] Full project update — was completely absent from the original server.ts
  app.patch(
    "/api/projects/:id",
    authenticate,
    can("projects:update"),
    async (req: any, res: any) => {
      try {
        const { id } = req.params;
        const existing = await prisma.project.findUnique({ where: { id } });
        if (!existing) return res.status(404).json({ error: "Projeto não encontrado" });

        // [F6] Same allowlist pattern — only known fields accepted
        const allowed = sanitizeProjectData(req.body, PROJECT_ALLOWED_UPDATE_FIELDS);

        const updated = await prisma.project.update({
          where: { id },
          data: {
            ...allowed,
            prazo: allowed.prazo ? new Date(allowed.prazo) : undefined,
            vigenciaInicio: allowed.vigenciaInicio ? new Date(allowed.vigenciaInicio) : undefined,
            vigenciaFim: allowed.vigenciaFim ? new Date(allowed.vigenciaFim) : undefined,
          },
          include: {
            responsavel: { select: { id: true, name: true, email: true, role: true } },
          },
        });

        await auditService.log({
          userId: req.user.id,
          projectId: id,
          acao: "UPDATE",
          entidade: "Project",
          entidadeId: id,
          antes: existing,
          depois: updated,
        });

        res.json(updated);
      } catch (error) {
        console.error("[PATCH /api/projects/:id]", error);
        res.status(400).json({ error: "Erro ao atualizar projeto" });
      }
    }
  );

  // [F7] Status-only update endpoint — was missing, causing "Atualizar Status"
  //      button in the frontend to have no backing API route.
  app.patch(
    "/api/projects/:id/status",
    authenticate,
    can("projects:update"),
    async (req: any, res: any) => {
      const { id } = req.params;
      const { status, justificativa } = req.body;

      const VALID_STATUSES = [
        "Oportunidade", "Triagem", "Elaboração", "Revisão", "Pronto",
        "Inscrito", "Diligência", "Aprovado", "Não Aprovado", "Captado",
        "Formalização", "Execução", "Concluído", "Arquivado",
      ];

      if (!status || !VALID_STATUSES.includes(status)) {
        return res.status(400).json({
          error: `Status inválido. Valores aceitos: ${VALID_STATUSES.join(", ")}`,
        });
      }

      try {
        const existing = await prisma.project.findUnique({ where: { id } });
        if (!existing) return res.status(404).json({ error: "Projeto não encontrado" });

        // Append the status change to the changeLog JSON field
        const currentLog = (existing.changeLog as any[]) || [];
        const newEntry = {
          id: crypto.randomUUID(),
          data: new Date().toISOString(),
          autor: req.user.email,
          campo: "status",
          valorAnterior: existing.status,
          valorNovo: status,
          justificativa: justificativa || null,
        };

        const updated = await prisma.project.update({
          where: { id },
          data: {
            status,
            changeLog: [...currentLog, newEntry],
          },
        });

        await auditService.log({
          userId: req.user.id,
          projectId: id,
          acao: "STATUS_CHANGE",
          entidade: "Project",
          entidadeId: id,
          antes: { status: existing.status },
          depois: { status },
        });

        res.json(updated);
      } catch (error) {
        console.error("[PATCH /api/projects/:id/status]", error);
        res.status(500).json({ error: "Erro ao atualizar status" });
      }
    }
  );

  // [F8] Delete endpoint — was missing
  app.delete(
    "/api/projects/:id",
    authenticate,
    can("projects:delete"),
    async (req: any, res: any) => {
      const { id } = req.params;
      try {
        const existing = await prisma.project.findUnique({ where: { id } });
        if (!existing) return res.status(404).json({ error: "Projeto não encontrado" });

        await prisma.project.delete({ where: { id } });

        await auditService.log({
          userId: req.user.id,
          acao: "DELETE",
          entidade: "Project",
          entidadeId: id,
          antes: existing,
        });

        res.status(204).send();
      } catch (error) {
        console.error("[DELETE /api/projects/:id]", error);
        res.status(500).json({ error: "Erro ao deletar projeto" });
      }
    }
  );

  // ── Expenses ───────────────────────────────────────────────────────────────
  app.post(
    "/api/expenses",
    authenticate,
    can("expenses:create"),
    async (req: any, res: any) => {
      const { projectId, descricao, valor, vincMetaId, vincEtapaId, cotacoes, data, categoria } =
        req.body;

      try {
        if (!vincMetaId || !vincEtapaId) {
          return res.status(400).json({
            error: "Vínculo com Meta e Etapa é obrigatório para evitar glosa.",
          });
        }

        if (valor > 1000 && (!cotacoes || cotacoes.length < 3)) {
          return res.status(400).json({
            error: "Despesas acima de R$ 1.000,00 exigem no mínimo 3 cotações.",
            actionRequired: "Anexar cotações faltantes",
          });
        }

        const meta = await prisma.meta.findUnique({ where: { id: vincMetaId } });
        if (!meta) return res.status(404).json({ error: "Meta não encontrada" });

        const existingExpenses = await prisma.expense.findMany({
          where: { vincMetaId, status: "VALIDADO" },
        });
        const totalSpent = existingExpenses.reduce((sum, e) => sum + e.valor, 0);

        if (totalSpent + valor > meta.budget) {
          await alertService.create({
            projectId,
            titulo: "Tentativa de Estouro de Orçamento",
            mensagem: `Tentativa de lançar despesa de R$ ${valor} na meta ${meta.descricao} (Saldo: R$ ${meta.budget - totalSpent})`,
            nivel: "N4",
            tipo: "ORCAMENTO",
          });
          return res.status(400).json({ error: "Saldo insuficiente na meta para esta despesa." });
        }

        const etapa = await prisma.etapa.findUnique({ where: { id: vincEtapaId } });
        if (!etapa) return res.status(404).json({ error: "Etapa não encontrada" });

        const expenseDate = new Date(data);
        if (expenseDate < etapa.inicio || expenseDate > etapa.fim) {
          return res
            .status(400)
            .json({ error: "Data da despesa fora do cronograma da etapa vinculada." });
        }

        const expense = await prisma.expense.create({
          data: {
            projectId,
            descricao,
            valor,
            data: expenseDate,
            categoria,
            status: "VALIDADO",
            vincMetaId,
            vincEtapaId,
            cotacoes: {
              create:
                cotacoes?.map((c: any) => ({
                  fornecedor: c.fornecedor,
                  valor: c.valor,
                  data: new Date(c.data),
                  vencedora: c.vencedora,
                  docUrl: c.docUrl,
                })) ?? [],
            },
          },
        });

        await auditService.log({
          userId: req.user.id,
          projectId,
          acao: "CREATE",
          entidade: "Expense",
          entidadeId: expense.id,
          depois: expense,
        });

        res.status(201).json(expense);
      } catch (error) {
        console.error("[POST /api/expenses]", error);
        res.status(500).json({ error: "Erro ao processar despesa" });
      }
    }
  );

  // ── Documents ──────────────────────────────────────────────────────────────
  app.get("/api/documents", authenticate, async (_req, res) => {
    const docs = await prisma.document.findMany({
      include: { project: { select: { id: true, nome: true } } },
      orderBy: { nome: "asc" },
    });
    res.json(docs);
  });

  app.post(
    "/api/documents",
    authenticate,
    can("documents:create"),
    async (req: any, res: any) => {
      const { projectId, nome, validade, url } = req.body;
      try {
        const doc = await prisma.document.create({
          data: {
            // [F4] projectId is now optional in schema — institutional docs allowed
            projectId: projectId ?? null,
            nome,
            validade: validade ? new Date(validade) : null,
            url,
            status: "Pendente",
          },
        });

        await auditService.log({
          userId: req.user.id,
          projectId: projectId ?? undefined,
          acao: "UPLOAD",
          entidade: "Document",
          entidadeId: doc.id,
          depois: doc,
        });

        res.status(201).json(doc);
      } catch (error) {
        console.error("[POST /api/documents]", error);
        res.status(400).json({ error: "Erro ao salvar documento" });
      }
    }
  );

  // ── Alerts ─────────────────────────────────────────────────────────────────
  app.get("/api/alerts", authenticate, can("alerts:read"), async (req: any, res: any) => {
    try {
      const isAdmin = ["SUPER_ADMIN", "DIRETORIA"].includes(req.user.role);
      const alerts = await prisma.alert.findMany({
        where: {
          status: "PENDENTE",
          ...(isAdmin ? {} : { project: { responsavelId: req.user.id } }),
        },
        include: { project: { select: { id: true, nome: true } } },
        orderBy: { createdAt: "desc" },
      });
      res.json(alerts);
    } catch (error) {
      console.error("[GET /api/alerts]", error);
      res.status(500).json({ error: "Erro ao buscar alertas" });
    }
  });

  app.patch("/api/alerts/:id/read", authenticate, async (req: any, res: any) => {
    try {
      const alert = await prisma.alert.update({
        where: { id: req.params.id },
        data: { lido: true, lidoEm: new Date(), lidoPor: req.user.id },
      });
      res.json(alert);
    } catch {
      res.status(404).json({ error: "Alerta não encontrado" });
    }
  });

  app.patch("/api/alerts/:id/resolve", authenticate, async (req: any, res: any) => {
    const { resolucao } = req.body;
    if (!resolucao?.trim()) {
      return res.status(400).json({ error: "Campo 'resolucao' é obrigatório" });
    }
    try {
      const alert = await prisma.alert.update({
        where: { id: req.params.id },
        data: { status: "RESOLVIDO", resolucao, lido: true, lidoEm: new Date(), lidoPor: req.user.id },
      });
      res.json(alert);
    } catch {
      res.status(404).json({ error: "Alerta não encontrado" });
    }
  });

  // ── Audit Logs ─────────────────────────────────────────────────────────────
  app.get("/api/audit-logs", authenticate, can("audit-logs:read"), async (_req, res) => {
    const logs = await prisma.auditLog.findMany({
      include: {
        user: { select: { id: true, name: true, email: true } },
        project: { select: { id: true, nome: true } },
      },
      orderBy: { data: "desc" },
      take: 50,
    });
    res.json(logs);
  });

  // ── Stats ──────────────────────────────────────────────────────────────────
  app.get("/api/stats", authenticate, can("stats:read"), async (_req, res) => {
    const [totalProjects, approvedProjects, totalValue] = await Promise.all([
      prisma.project.count(),
      prisma.project.count({ where: { status: "Aprovado" } }),
      prisma.project.aggregate({ _sum: { valor: true } }),
    ]);

    res.json({
      totalProjects,
      approvedProjects,
      totalValue: totalValue._sum.valor || 0,
      approvalRate: totalProjects > 0 ? (approvedProjects / totalProjects) * 100 : 0,
    });
  });

  // ── Vite / Static ──────────────────────────────────────────────────────────
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  // [F5] Use PORT from env — was hardcoded to 3000
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ROTA server running on http://localhost:${PORT}`);
  });
}

process.on("unhandledRejection", (reason) => {
  console.error("[unhandledRejection]", reason);
});
process.on("uncaughtException", (error) => {
  console.error("[uncaughtException]", error);
});

startServer();
